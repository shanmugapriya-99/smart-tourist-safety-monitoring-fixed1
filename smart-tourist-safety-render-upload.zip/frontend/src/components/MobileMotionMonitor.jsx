import React, { useEffect, useRef, useState } from 'react';
import { api } from '../api';

// Browser motion sensors provide clues, not a medical-grade fall diagnosis.
const magnitude = (x, y, z) => Math.sqrt((x || 0) ** 2 + (y || 0) ** 2 + (z || 0) ** 2);

export default function MobileMotionMonitor({ coords, onIncidentCreated }) {
  const [enabled, setEnabled] = useState(false);
  const [status, setStatus] = useState('Sensor monitoring is off');
  const [candidate, setCandidate] = useState(null);
  const [busy, setBusy] = useState(false);
  const [sensorAvailable, setSensorAvailable] = useState(true);
  const freeFallAt = useRef(0);
  const impactAt = useRef(0);
  const lastAlertAt = useRef(0);
  const stillSince = useRef(0);
  const readings = useRef([]);

  useEffect(() => {
    if (!enabled) return undefined;
    if (!('DeviceMotionEvent' in window)) {
      setSensorAvailable(false);
      setStatus('This browser does not provide motion sensor access.');
      setEnabled(false);
      return undefined;
    }
    const handleMotion = (event) => {
      const acc = event.accelerationIncludingGravity || event.acceleration;
      if (!acc) return;
      const now = Date.now();
      const g = magnitude(acc.x, acc.y, acc.z);
      readings.current.push(g);
      if (readings.current.length > 12) readings.current.shift();

      // Approximate thresholds in m/s². Device models and carrying position vary.
      if (g < 4.5) freeFallAt.current = now;
      const followedFreeFall = now - freeFallAt.current < 1800;
      const hardImpact = g > 24;
      const veryHardImpact = g > 29;

      if (g > 7 && g < 13) {
        if (!stillSince.current) stillSince.current = now;
      } else if (g > 15) {
        stillSince.current = 0;
      }

      if ((followedFreeFall && hardImpact) || veryHardImpact) {
        if (now - lastAlertAt.current < 12000) return;
        lastAlertAt.current = now;
        impactAt.current = now;
        const possibleFall = stillSince.current && now - stillSince.current > 1200;
        setCandidate({
          type: possibleFall ? 'POSSIBLE_TOURIST_FALL' : 'POSSIBLE_PHONE_DROP',
          title: possibleFall ? 'Possible tourist fall detected' : 'Possible phone drop detected',
          details: `A sudden motion and impact pattern was detected (${g.toFixed(1)} m/s²).`,
        });
        setStatus('Possible incident detected — please confirm your safety.');
      }
    };
    window.addEventListener('devicemotion', handleMotion, true);
    setStatus('Motion sensor monitoring is active');
    return () => window.removeEventListener('devicemotion', handleMotion, true);
  }, [enabled]);

  const startMonitoring = async () => {
    try {
      // iOS 13+ requires permission from a direct user gesture.
      if (typeof DeviceMotionEvent.requestPermission === 'function') {
        const permission = await DeviceMotionEvent.requestPermission();
        if (permission !== 'granted') {
          setStatus('Motion sensor permission was not granted.');
          return;
        }
      }
      setEnabled(true);
      setStatus('Requesting motion sensor readings…');
    } catch (error) {
      setStatus(`Could not start motion sensors: ${error.message}`);
    }
  };

  const reportIncident = async () => {
    if (!coords?.latitude || !coords?.longitude) {
      setStatus('GPS coordinates are required before sending an alert.');
      return;
    }
    setBusy(true);
    try {
      const type = candidate?.type === 'POSSIBLE_TOURIST_FALL' ? 'FALL_DETECTION' : 'PHONE_DROP';
      const result = await api.triggerSOS({
        latitude: coords.latitude,
        longitude: coords.longitude,
        incident_type: type,
        notes: `${candidate?.title || 'Possible motion incident'} confirmed by tourist. ${candidate?.details || ''}`,
      });
      if (result.incident && onIncidentCreated) onIncidentCreated(result.incident);
      setCandidate(null);
      setStatus('Alert sent to the admin dashboard.');
    } catch (error) {
      setStatus(`Alert could not be sent: ${error.message}. Please use the SOS button if you need help.`);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-5">
      <div className="rounded-2xl border border-cyan-800/60 bg-slate-900 p-5 shadow-lg">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div>
            <h3 className="text-lg font-bold text-white">Mobile Motion Safety Sensors</h3>
            <p className="mt-1 text-sm text-slate-300">Uses your phone's accelerometer to flag possible phone drops or tourist falls.</p>
          </div>
          {!enabled ? (
            <button onClick={startMonitoring} className="rounded-lg bg-cyan-600 px-4 py-2 font-semibold text-white hover:bg-cyan-500">Enable phone sensors</button>
          ) : (
            <button onClick={() => { setEnabled(false); setCandidate(null); setStatus('Sensor monitoring is off'); }} className="rounded-lg border border-slate-600 px-4 py-2 font-semibold text-slate-200">Stop monitoring</button>
          )}
        </div>
        <p className="mt-3 text-sm text-cyan-200" role="status">{status}</p>
        {!sensorAvailable && <p className="mt-2 text-sm text-amber-300">Try a compatible mobile browser over HTTPS.</p>}
        {candidate && (
          <div className="mt-4 rounded-xl border border-amber-500/60 bg-amber-950/40 p-4">
            <p className="font-bold text-amber-200">{candidate.title}</p>
            <p className="mt-1 text-sm text-slate-200">{candidate.details}</p>
            <p className="mt-2 text-sm text-slate-300">Are you safe? Only send an alert if this is a real emergency.</p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button disabled={busy} onClick={reportIncident} className="rounded-lg bg-red-600 px-4 py-2 font-semibold text-white disabled:opacity-50">{busy ? 'Sending…' : 'I need help — send alert'}</button>
              <button disabled={busy} onClick={() => { setCandidate(null); setStatus('Alert dismissed. Sensor monitoring continues.'); }} className="rounded-lg border border-slate-500 px-4 py-2 text-slate-100">I'm safe</button>
            </div>
          </div>
        )}
        <p className="mt-3 text-xs text-slate-400">Keep this page open and the phone with you. Sensor patterns cannot reliably tell a dropped phone from a person falling; this feature is experimental and does not replace the SOS button or emergency services.</p>
      </div>
    </section>
  );
}
