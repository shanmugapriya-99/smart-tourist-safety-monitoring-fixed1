import React from 'react';

export default function Navbar({
  currentView,
  setCurrentView,
  user,
  onLogout,
  onOpenLogin,
  onOpenRegister,
  activeAlertCount = 0
}) {
  return (
    <header className="sticky top-0 z-50 bg-navy-900/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Logo & Project Title */}
          <div 
            onClick={() => setCurrentView('landing')}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-cyan-400 flex items-center justify-center text-white shadow-lg shadow-blue-500/25 group-hover:scale-105 transition-transform">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight bg-gradient-to-r from-white via-slate-100 to-blue-200 bg-clip-text text-transparent">
                  TouristSafe<span className="text-blue-500">AI</span>
                </span>
                <span className="hidden sm:inline-block text-[10px] font-mono font-semibold uppercase px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20">
                  Geo-Fence & Blockchain
                </span>
              </div>
              <p className="hidden md:block text-[11px] text-slate-400">Smart Safety & Incident Response System</p>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1 text-sm font-medium">
            <button
              onClick={() => setCurrentView('landing')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${currentView === 'landing' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              Overview
            </button>
            <button
              onClick={() => setCurrentView('tourist')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${currentView === 'tourist' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              <span>Tourist Portal</span>
            </button>
            <button
              onClick={() => setCurrentView('admin')}
              className={`px-3 py-1.5 rounded-lg transition-colors flex items-center gap-1.5 ${currentView === 'admin' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              <span>Admin Center</span>
              {activeAlertCount > 0 && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
              )}
            </button>
            <button
              onClick={() => setCurrentView('map')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${currentView === 'map' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              Live Radar
            </button>
            <button
              onClick={() => setCurrentView('blockchain')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${currentView === 'blockchain' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              Blockchain Ledger
            </button>
            <button
              onClick={() => setCurrentView('ai')}
              className={`px-3 py-1.5 rounded-lg transition-colors ${currentView === 'ai' ? 'bg-blue-600 text-white' : 'text-slate-300 hover:text-white hover:bg-slate-800'}`}
            >
              AI Safety Bot
            </button>
          </nav>

          {/* User Status & Action Buttons */}
          <div className="flex items-center gap-3">
            {/* Quick Emergency Call Pill */}
            <a
              href="tel:112"
              title="Official Emergency Services (Demo)"
              className="hidden sm:flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-red-500/10 text-red-400 border border-red-500/30 hover:bg-red-500/20 transition-colors"
            >
              <svg className="w-3.5 h-3.5 animate-pulse text-red-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2a1 1 0 011.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.57a1 1 0 01-.24 1.02l-2.21 2.2z"/>
              </svg>
              <span>112 Helpline</span>
            </a>

            {user ? (
              <div className="flex items-center gap-3">
                <div className="hidden sm:block text-right">
                  <div className="text-xs font-bold text-white leading-tight">{user.name}</div>
                  <div className="text-[10px] font-mono text-blue-400">
                    {user.role === 'admin' ? '🛡️ Admin HQ' : `ID: ${user.tourist_id || 'Active'}`}
                  </div>
                </div>
                <button
                  onClick={onLogout}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={onOpenLogin}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors border border-slate-700"
                >
                  Sign In
                </button>
                <button
                  onClick={onOpenRegister}
                  className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white transition-all shadow-md shadow-blue-500/20"
                >
                  Register
                </button>
              </div>
            )}
          </div>

        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="lg:hidden flex items-center justify-around border-t border-slate-800 py-2 px-2 bg-navy-950/90 text-xs">
        <button
          onClick={() => setCurrentView('tourist')}
          className={`px-2 py-1 rounded ${currentView === 'tourist' ? 'text-blue-400 font-bold' : 'text-slate-400'}`}
        >
          Tourist
        </button>
        <button
          onClick={() => setCurrentView('admin')}
          className={`px-2 py-1 rounded ${currentView === 'admin' ? 'text-blue-400 font-bold' : 'text-slate-400'}`}
        >
          Admin
        </button>
        <button
          onClick={() => setCurrentView('map')}
          className={`px-2 py-1 rounded ${currentView === 'map' ? 'text-blue-400 font-bold' : 'text-slate-400'}`}
        >
          Radar
        </button>
        <button
          onClick={() => setCurrentView('blockchain')}
          className={`px-2 py-1 rounded ${currentView === 'blockchain' ? 'text-blue-400 font-bold' : 'text-slate-400'}`}
        >
          Blockchain
        </button>
        <button
          onClick={() => setCurrentView('ai')}
          className={`px-2 py-1 rounded ${currentView === 'ai' ? 'text-blue-400 font-bold' : 'text-slate-400'}`}
        >
          AI Bot
        </button>
      </div>
    </header>
  );
}
