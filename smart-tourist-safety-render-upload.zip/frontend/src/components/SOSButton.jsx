import React, { useState, useEffect } from 'react';
import { api } from '../api';

export default function SOSButton({
  user,
  currentCoords,
  isTracking,
  onIncidentCreated
}) {
  const [isOpenModal, setIsOpenModal] = useState(false);
  const [countdown, setCountdown] = useState(5);
  const [countdownActive, setCountdownActive] = useState(false);
  const [incidentType, setIncidentType] = useState('SOS');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [sosResult, setSosResult] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Countdown timer when modal opens
  useEffect(() => {
    let timer;
    if (countdownActive && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown((prev) => prev - 1);
      }, 1000);
    }
    return () => clearTimeout(timer);
  }, [countdownActive, countdown]);

  const handleOpenSOS = () => {
    setErrorMsg('');
    setSosResult(null);
    setCountdown(5);
    setCountdownActive(true);
    setIsOpenModal(true);
  };

  const handleCancelCountdown = () => {
    setCountdownActive(false);
    setIsOpenModal(false);
  };

  const handleConfirmSOS = async () => {
    setCountdownActive(false);
    setIsSubmitting(true);
    setErrorMsg('');

    // Fallback coordinates if GPS not yet retrieved (e.g. Scenic Goa beach)
    const lat = currentCoords ? currentCoords.latitude : 15.4950;
    const lng = currentCoords ? currentCoords.longitude : 73.8180;

    try {
      const payload = {
        latitude: lat,
        longitude: lng,
        incident_type: incidentType,
        notes: notes.trim() || `Emergency SOS triggered by ${user?.name || 'Tourist'}`,
        battery_level: navigator.getBattery ? 82 : 88,
      };

      const res = await api.triggerSOS(payload);
      setSosResult(res);
      if (onIncidentCreated) {
        onIncidentCreated(res.incident);
      }
    } catch (err) {
      setErrorMsg(err.message || 'Failed to dispatch SOS alert. Please try again or call 112 directly.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <>
      {/* The Giant SOS Button Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-red-950/40 via-navy-900 to-navy-900 border border-red-500/30 shadow-2xl relative overflow-hidden text-center">
        <div className="absolute -top-12 -right-12 w-36 h-36 bg-red-600/10 rounded-full blur-2xl pointer-events-none" />

        <div className="max-w-md mx-auto">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/10 text-red-400 border border-red-500/20 mb-3">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-ping"></span>
            24/7 COMMAND CENTER RAPID RESPONSE
          </div>

          <h3 className="text-xl font-extrabold text-white mb-1">Emergency SOS Trigger</h3>
          <p className="text-xs text-slate-300 mb-6">
            Pressing SOS captures your live GPS coordinates, initiates emergency triage, 
            and alerts safety patrol responders immediately.
          </p>

          {/* Glowing Red Button */}
          <div className="flex justify-center my-4">
            <button
              onClick={handleOpenSOS}
              className="sos-glow-button w-36 h-36 sm:w-40 sm:h-40 rounded-full bg-gradient-to-tr from-red-700 via-red-600 to-rose-500 hover:from-red-600 hover:to-rose-400 text-white font-black text-2xl sm:text-3xl tracking-widest uppercase shadow-2xl shadow-red-600/50 flex flex-col items-center justify-center gap-1 transition-transform active:scale-95 border-4 border-red-400/50"
            >
              <svg className="w-8 h-8 sm:w-10 sm:h-10 text-white animate-bounce-gentle" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <span>SOS</span>
              <span className="text-[10px] font-sans font-normal tracking-normal opacity-90">EMERGENCY</span>
            </button>
          </div>

          {/* Quick Direct Call & Disclaimer */}
          <div className="mt-6 pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
            <a
              href="tel:112"
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-red-950/60 text-red-300 border border-red-500/30 hover:bg-red-900/50 transition-colors font-semibold"
            >
              <svg className="w-4 h-4 text-red-400" fill="currentColor" viewBox="0 0 24 24">
                <path d="M6.62 10.79a15.053 15.053 0 006.59 6.59l2.2-2.2a1 1 0 011.01-.24c1.12.37 2.33.57 3.58.57a1 1 0 011 1V20a1 1 0 01-1 1A17 17 0 013 4a1 1 0 011-1h3.5a1 1 0 011 1c0 1.25.2 2.45.57 3.57a1 1 0 01-.24 1.02l-2.21 2.2z"/>
              </svg>
              <span>Call Emergency (112)</span>
            </a>
            <span className="text-[11px] text-slate-400">
              ⚠️ Academic Demo: Does not auto-call 911/police.
            </span>
          </div>

        </div>
      </div>

      {/* SOS Confirmation Modal */}
      {isOpenModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-navy-900 border border-red-500/40 rounded-2xl max-w-lg w-full p-6 shadow-2xl relative">
            
            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-500/20 text-red-400 flex items-center justify-center font-bold text-lg">
                  🚨
                </div>
                <div>
                  <h4 className="text-lg font-bold text-white">Emergency SOS Confirmation</h4>
                  <p className="text-xs text-slate-400">Verify distress details before dispatching responders</p>
                </div>
              </div>
              <button
                onClick={handleCancelCountdown}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            {/* If Alert Dispatched Successfully */}
            {sosResult ? (
              <div className="py-6 text-center space-y-4">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 mx-auto flex items-center justify-center text-3xl">
                  ✓
                </div>
                <h4 className="text-xl font-bold text-white">SOS Broadcast Received!</h4>
                <p className="text-xs text-emerald-300 font-mono bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-800/40">
                  Incident ID: {sosResult.incident?.incident_id} | Block #{sosResult.incident?.block_index} Mined
                </p>

                {/* AI Triage Banner */}
                {sosResult.ai_triage && (
                  <div className="text-left bg-navy-800 p-4 rounded-xl border border-slate-700 space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-300">AI Triage Classification:</span>
                      <span className="font-mono font-bold text-red-400 uppercase px-2 py-0.5 rounded bg-red-500/10 border border-red-500/20">
                        {sosResult.ai_triage.priority_level}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-slate-300">Dispatched Team:</span>
                      <span className="text-cyan-300 font-semibold">{sosResult.ai_triage.recommended_unit}</span>
                    </div>
                    <div className="pt-2 border-t border-slate-700">
                      <p className="font-semibold text-amber-300 mb-1">🩹 First-Aid Instructions for You:</p>
                      <p className="text-slate-300 leading-relaxed">{sosResult.ai_triage.automated_first_aid}</p>
                    </div>
                  </div>
                )}

                {/* Open in Google Maps */}
                <div className="flex flex-wrap gap-2 justify-center pt-2">
                  <a
                    href={`https://maps.google.com/?q=${sosResult.incident?.latitude},${sosResult.incident?.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <span>View in Google Maps</span>
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                  <button
                    onClick={() => {
                      setIsOpenModal(false);
                      setSosResult(null);
                    }}
                    className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                  >
                    Close Window
                  </button>
                </div>
              </div>
            ) : (
              /* Confirmation Form & Countdown */
              <div className="py-4 space-y-4">
                
                {/* Countdown Warning Banner */}
                {countdownActive && countdown > 0 && (
                  <div className="flex items-center justify-between p-3 rounded-xl bg-red-950/40 border border-red-500/30 text-xs text-red-200">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping"></span>
                      <span>To prevent accidental alerts, confirm or cancel:</span>
                    </div>
                    <span className="font-mono font-bold text-sm bg-red-500/20 px-2 py-0.5 rounded text-white">
                      {countdown}s
                    </span>
                  </div>
                )}

                {/* GPS Coordinates readout */}
                <div className="bg-navy-950 p-3 rounded-xl border border-slate-800 text-xs space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Captured GPS Location:</span>
                    <span className="text-emerald-400 font-mono">
                      {currentCoords ? '✓ Real Device GPS' : '📍 Demo Geolocation (Goa Coast)'}
                    </span>
                  </div>
                  <div className="font-mono text-white text-sm">
                    {currentCoords ? `${currentCoords.latitude.toFixed(5)}, ${currentCoords.longitude.toFixed(5)}` : '15.49500, 73.81800'}
                  </div>
                  <div className="text-[11px] text-slate-400 flex justify-between">
                    <span>Accuracy: ±{currentCoords?.accuracy ? Math.round(currentCoords.accuracy) : 10} meters</span>
                    <span>Tourist: {user?.name || 'Registered Tourist'}</span>
                  </div>
                </div>

                {/* Emergency Type Selector */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Distress Category:
                  </label>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {[
                      { id: 'SOS', label: '🚨 General SOS Emergency' },
                      { id: 'MEDICAL', label: '🩹 Medical Injury / Snakebite' },
                      { id: 'LOST', label: '🌲 Lost on Unmarked Trail' },
                      { id: 'CLIFF', label: '🌊 Coastal / Cliff Hazard' },
                    ].map((t) => (
                      <button
                        key={t.id}
                        type="button"
                        onClick={() => setIncidentType(t.id)}
                        className={`p-2 rounded-lg text-left border transition-all ${
                          incidentType === t.id
                            ? 'bg-red-500/20 border-red-500 text-white font-semibold'
                            : 'bg-navy-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        {t.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Additional Notes input */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Situation Details (Optional):
                  </label>
                  <input
                    type="text"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="e.g. Swollen ankle, cannot walk, near lighthouse trail"
                    className="w-full px-3 py-2 rounded-lg bg-navy-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-red-500"
                  />
                </div>

                {errorMsg && (
                  <p className="text-xs text-red-400 bg-red-950/40 p-2 rounded-lg border border-red-900">
                    {errorMsg}
                  </p>
                )}

                {/* Modal Buttons */}
                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
                  <button
                    type="button"
                    onClick={handleCancelCountdown}
                    className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                  >
                    Cancel Alert
                  </button>
                  <button
                    type="button"
                    disabled={isSubmitting}
                    onClick={handleConfirmSOS}
                    className="px-5 py-2 rounded-lg text-xs font-bold bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/30 transition-all flex items-center gap-1.5"
                  >
                    {isSubmitting ? (
                      <>
                        <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                        <span>Broadcasting...</span>
                      </>
                    ) : (
                      <>
                        <span>🚨 CONFIRM & DISPATCH NOW</span>
                      </>
                    )}
                  </button>
                </div>

              </div>
            )}

          </div>
        </div>
      )}
    </>
  );
}
