import React, { useState } from 'react';
import SOSButton from './SOSButton';
import LiveMap from './LiveMap';
import DigitalIDCard from './DigitalIDCard';

export default function TouristDashboard({
  user,
  currentCoords,
  isTracking,
  locationError,
  lastUpdated,
  dangerZones,
  aiSafetyScore,
  onToggleTracking,
  onSimulateMove,
  onIncidentCreated,
  onViewDigitalID,
  onViewBlockchain,
}) {
  const [activeTab, setActiveTab] = useState('overview'); // 'overview' or 'digital-id'

  return (
    <div className="py-6 sm:py-8 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
      
      {/* Top Welcome & Safety Status Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-navy-900 via-navy-850 to-navy-900 border border-slate-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        
        {/* Tourist Profile Details */}
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-md text-xs font-mono font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20">
              {user?.tourist_id || 'TRV-DEMO-01'}
            </span>
            <span className="px-2.5 py-1 rounded-md text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              Verified Digital ID Active
            </span>
            {user?.blood_group && (
              <span className="px-2 py-0.5 rounded text-xs font-bold bg-rose-500/10 text-rose-300 border border-rose-500/20">
                Blood: {user.blood_group}
              </span>
            )}
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold text-white">
            Hello, {user?.name || 'Valued Traveler'}!
          </h2>
          <p className="text-xs sm:text-sm text-slate-300">
            Emergency Contact: <strong className="text-white">{user?.emergency_contact || 'Command Patrol'}</strong> ({user?.emergency_phone || '112'})
          </p>
        </div>

        {/* Dynamic AI Safety Index Score Card */}
        <div className="flex items-center gap-4 p-4 rounded-xl bg-navy-950/80 border border-slate-800 self-start md:self-auto">
          <div className="relative w-16 h-16 flex items-center justify-center">
            <svg className="w-16 h-16 -rotate-90" viewBox="0 0 36 36">
              <path
                className="text-slate-800"
                strokeWidth="3.5"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
              <path
                className={
                  (aiSafetyScore?.safety_score || 95) >= 75
                    ? 'text-emerald-400'
                    : (aiSafetyScore?.safety_score || 95) >= 50
                    ? 'text-amber-400'
                    : 'text-red-500'
                }
                strokeDasharray={`${aiSafetyScore?.safety_score || 95}, 100`}
                strokeWidth="3.5"
                strokeLinecap="round"
                stroke="currentColor"
                fill="none"
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
              />
            </svg>
            <div className="absolute text-center">
              <span className="text-base font-extrabold text-white">
                {aiSafetyScore?.safety_score || 95}%
              </span>
            </div>
          </div>

          <div>
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              AI Safety Index
            </div>
            <div className="text-sm font-bold text-white">
              {aiSafetyScore?.status || 'OPTIMAL'}
            </div>
            <div className="text-[11px] text-slate-400 max-w-[200px] truncate">
              {aiSafetyScore?.recommendation || 'Safe tourist corridor'}
            </div>
          </div>
        </div>

      </div>

      {/* Main Grid: Live GPS Tracking & Emergency SOS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Column: GPS Tracking & Location Card */}
        <div className="lg:col-span-1 space-y-6">
          
          {/* Tracking Controller */}
          <div className="p-6 rounded-2xl bg-navy-900 border border-slate-800 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-400 flex items-center justify-center">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  </svg>
                </div>
                <h3 className="text-base font-bold text-white">GPS Safety Tracking</h3>
              </div>

              {/* Start / Stop Toggle Button */}
              <button
                onClick={onToggleTracking}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all shadow-md ${
                  isTracking
                    ? 'bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30'
                    : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                }`}
              >
                {isTracking ? '⏹ Stop Tracking' : '▶ Start Tracking'}
              </button>
            </div>

            {/* Error Message if GPS denied */}
            {locationError && (
              <div className="p-3 rounded-xl bg-amber-950/40 border border-amber-500/40 text-xs text-amber-200">
                <p className="font-semibold mb-1">📍 Geolocation Notice:</p>
                <p>{locationError}</p>
                <p className="text-[11px] text-amber-300/80 mt-1">
                  Using high-precision demo coordinates (Scenic Beach / Resort trail).
                </p>
              </div>
            )}

            {/* Coordinates Readout */}
            <div className="bg-navy-950 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Tracking Status:</span>
                <span className={`font-semibold ${isTracking ? 'text-emerald-400' : 'text-slate-400'}`}>
                  {isTracking ? '● Active (Consent Granted)' : '○ Paused by User'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Latitude:</span>
                <span className="font-mono text-white">
                  {currentCoords ? currentCoords.latitude.toFixed(6) : '15.495000'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Longitude:</span>
                <span className="font-mono text-white">
                  {currentCoords ? currentCoords.longitude.toFixed(6) : '73.818000'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Accuracy:</span>
                <span className="font-mono text-slate-300">
                  ±{currentCoords?.accuracy ? Math.round(currentCoords.accuracy) : 10} meters
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Last Synced:</span>
                <span className="text-slate-400">
                  {lastUpdated ? lastUpdated.toLocaleTimeString() : 'Just now'}
                </span>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 leading-relaxed">
              🔒 <strong>Privacy Assurance:</strong> Location is only captured with your explicit consent and shared strictly with authorized emergency responders during active tracking.
            </p>
          </div>

          {/* Quick Digital ID Pass Card */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-blue-950/40 to-navy-900 border border-blue-500/20 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-lg">🪪</span>
                <h4 className="text-sm font-bold text-white">Tourist Digital Identity</h4>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-300">
                SHA-256
              </span>
            </div>
            <p className="text-xs text-slate-300">
              Your verifiable digital identity pass is cryptographically anchored to the safety blockchain ledger.
            </p>
            <div className="pt-2 flex gap-2">
              <button
                onClick={() => setActiveTab(activeTab === 'digital-id' ? 'overview' : 'digital-id')}
                className="flex-1 py-2 px-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-semibold shadow-md transition-colors"
              >
                {activeTab === 'digital-id' ? 'Hide ID Card' : 'View Full ID & QR Code'}
              </button>
              <button
                onClick={onViewBlockchain}
                className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium border border-slate-700 transition-colors"
              >
                Blockchain
              </button>
            </div>
          </div>

          {/* Local Helplines Grid */}
          <div className="p-4 rounded-2xl bg-navy-900/60 border border-slate-800 space-y-2">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Emergency Direct Numbers
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <a
                href="tel:112"
                className="p-2.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-red-300 font-semibold flex items-center justify-between border border-slate-700"
              >
                <span>National SOS</span>
                <span className="font-mono font-bold">112</span>
              </a>
              <a
                href="tel:108"
                className="p-2.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-emerald-300 font-semibold flex items-center justify-between border border-slate-700"
              >
                <span>Ambulance</span>
                <span className="font-mono font-bold">108</span>
              </a>
              <a
                href="tel:100"
                className="p-2.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-blue-300 font-semibold flex items-center justify-between border border-slate-700"
              >
                <span>Police</span>
                <span className="font-mono font-bold">100</span>
              </a>
              <a
                href="tel:1363"
                className="p-2.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-purple-300 font-semibold flex items-center justify-between border border-slate-700"
              >
                <span>Tourist Help</span>
                <span className="font-mono font-bold">1363</span>
              </a>
            </div>
          </div>

        </div>

        {/* Right Column: SOS Trigger & Live Radar Map */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Emergency SOS Button Section */}
          <SOSButton
            user={user}
            currentCoords={currentCoords}
            isTracking={isTracking}
            onIncidentCreated={onIncidentCreated}
          />

          {/* If Digital ID expanded, show ID Card */}
          {activeTab === 'digital-id' ? (
            <DigitalIDCard user={user} />
          ) : (
            /* Interactive Live Map */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">Live Safety Radar & Geo-Fences</h3>
                  <p className="text-xs text-slate-400">
                    Your real-time position mapped relative to active hazard zones
                  </p>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                  {dangerZones?.length || 3} Hazard Zones Monitored
                </span>
              </div>

              <LiveMap
                userCoords={currentCoords}
                dangerZones={dangerZones}
                onSimulateMove={onSimulateMove}
                isTracking={isTracking}
                isAdmin={false}
              />
            </div>
          )}

        </div>

      </div>

    </div>
  );
}
