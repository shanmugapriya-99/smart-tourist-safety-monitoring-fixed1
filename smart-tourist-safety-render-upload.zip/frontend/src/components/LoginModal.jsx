import React, { useState } from 'react';

export default function LoginModal({
  isOpen,
  onClose,
  onLogin,
  onSwitchToRegister
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setLoading(true);

    try {
      await onLogin(email, password);
      onClose();
    } catch (err) {
      setErrorMsg(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const fillTouristDemo = () => {
    setEmail('tourist@example.com');
    setPassword('tourist123');
  };

  const fillAdminDemo = () => {
    setEmail('admin@touristsafety.org');
    setPassword('admin123');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
      <div className="bg-navy-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl relative text-white">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-white p-1"
        >
          ✕
        </button>

        {/* Modal Title */}
        <div className="mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-mono font-bold bg-blue-500/10 text-blue-400 border border-blue-500/20 mb-2">
            SECURE ACCESS PORTAL
          </div>
          <h3 className="text-2xl font-black text-white">Sign In</h3>
          <p className="text-xs text-slate-400 mt-1">
            Access your Tourist Safety Dashboard or Admin Command Center
          </p>
        </div>

        {/* 1-Click Quick Fill Pills */}
        <div className="mb-6 p-3 rounded-2xl bg-navy-950 border border-slate-800 space-y-2">
          <span className="text-[10px] font-mono uppercase text-slate-400 block font-semibold">
            ⚡ Quick Evaluator Logins (1-Click Fill)
          </span>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              type="button"
              onClick={fillTouristDemo}
              className="py-1.5 px-2.5 rounded-xl bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 text-center font-medium transition-colors"
            >
              Tourist Demo
            </button>
            <button
              type="button"
              onClick={fillAdminDemo}
              className="py-1.5 px-2.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-center font-medium transition-colors"
            >
              Admin HQ Demo
            </button>
          </div>
        </div>

        {/* Login Form */}
        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block text-slate-300 font-semibold mb-1">Email Address</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. tourist@example.com"
              className="w-full px-4 py-2.5 rounded-xl bg-navy-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          <div>
            <label className="block text-slate-300 font-semibold mb-1">Password</label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="w-full px-4 py-2.5 rounded-xl bg-navy-950 border border-slate-800 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
            />
          </div>

          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs">
              {errorMsg}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-bold text-sm shadow-lg shadow-blue-500/25 transition-all mt-2"
          >
            {loading ? 'Authenticating...' : 'Sign In to Portal'}
          </button>
        </form>

        {/* Switch to Register */}
        <div className="mt-6 pt-4 border-t border-slate-800 text-center text-xs text-slate-400">
          First time traveler?{' '}
          <button
            onClick={() => {
              onClose();
              onSwitchToRegister();
            }}
            className="text-cyan-400 hover:underline font-semibold"
          >
            Register for Digital ID
          </button>
        </div>

      </div>
    </div>
  );
}
